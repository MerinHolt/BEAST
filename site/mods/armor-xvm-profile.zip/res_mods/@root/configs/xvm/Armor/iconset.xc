﻿/**
 * Icons set atlases.
 * Атласы с набором иконок.
 *
 * Path relative to:
 * Пути относительно:
 *   res_mods/x.x.x/gui/flash/atlases.
 */
{
  "iconset": {
    // Path to the atlas with icons for the battle loading screen.
    // Путь к атласу с иконками для экрана загрузки боя.
    "battleLoadingLeftAtlas": "battleAtlasL",
    "battleLoadingRightAtlas": "battleAtlasR",
    // Path to the atlas with icons for the players panels.
    // Путь к атласу с иконками для "ушей".
    "playersPanelLeftAtlas": "battleAtlasL",
    "playersPanelRightAtlas": "battleAtlasR",
    // Path to the atlas with icons for the full stats form (on "Tab" key pressed).
    // Путь к атласу с иконками для формы подробной статистики (при нажатии клавиши "Tab").
    "fullStatsLeftAtlas": "battleAtlasL",
    "fullStatsRightAtlas": "battleAtlasR",
    // Path to the atlas with icons for the over-target markers.
    // Путь к атласу с иконками для маркеров над танками.
    "vehicleMarkerAllyAtlas": "vehicleMarkerAtlasL",
    "vehicleMarkerEnemyAtlas": "vehicleMarkerAtlasR"
  }
}