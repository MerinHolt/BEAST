﻿{
	"damageDealtL": {
		// Цифры нанесенного союзником урона	
		"damageDealt": {
			"hotKeyCode": 56,
			"onHold": "true",
			"visibleOnHotKey": ${"teams_damage.xc":"visibleOnHotKey"},
			"bindToIcon": true,
			"alpha": "{{{{py:player_damage.player_damage('{{name}}')}}>0?{{alive?100|80}}|0}}",
			"x": 91,
			"width": 42,
			"y": 5,
			"textFormat": { "font": "$FieldFont", "size": 13, "color": "#FFFFFF", "bold": "{{player?true|false}}", "align": "center" },
			"format": "{{py:player_damage.player_damage('{{name}}')}}",
			"shadow": {"enabled": true, "color": "0x000000", "alpha": 100, "blur": 1, "strength": 2, "distance": 0, "angle": 0}	  
		},	  
        // Подложка индикатора HP слева.
		"damageDealtBg": {
			"hotKeyCode": 56,
			"onHold": "true",
			"visibleOnHotKey": ${"teams_damage.xc":"visibleOnHotKey"},
			"x": 88,
			"y": 5,
			"bindToIcon": true,
			"alpha": "{{{{py:player_damage.player_damage('{{name}}')}}>0?{{alive?55|30}}|0}}",
			"format": "{{player?<img src='xvm://res/icons/pp_dmg_bg/dmg_bg_gold.png' width='44' height='16'>|{{alive?<img src='xvm://res/icons/pp_dmg_bg/dmg_bg_green.png' width='44' height='16'>|<img src='xvm://res/icons/pp_dmg_bg/dmg_bg_gray.png' width='44' height='16'>}}}}"
		}
	},
	"damageDealtR": {
		// Цифры нанесенного противником урона	
		"damageDealt": {
			"hotKeyCode": 56,
			"onHold": "true",
			"visibleOnHotKey": ${"teams_damage.xc":"visibleOnHotKey"},
			"bindToIcon": true,
			"alpha": "{{{{py:player_damage.player_damage('{{name}}')}}>0?{{alive?100|80}}|0}}", 
			"x": 91,
			"width": 42,
			"y": 5,
			"textFormat": { "font": "$FieldFont", "size": 13, "color": "#FFFFFF", "bold": "false", "align": "center" },
			"format": "{{py:player_damage.player_damage('{{name}}')}}",
			"shadow": {"enabled": true, "color": "0x000000", "alpha": 100, "blur": 1, "strength": 2, "distance": 0, "angle": 0}	  
		},	  
        // Подложка индикатора HP права.
		"damageDealtBg": {
			"hotKeyCode": 56,
			"onHold": "true",
			"visibleOnHotKey": ${"teams_damage.xc":"visibleOnHotKey"},
			"x": 88,
			"y": 5,
			"bindToIcon": true,
			"alpha": "{{{{py:player_damage.player_damage('{{name}}')}}>0?{{alive?45|30}}|0}}",
			"format": "{{alive?<img src='xvm://res/icons/pp_dmg_bg/dmg_bg_red.png' width='44' height='16'>|<img src='xvm://res/icons/pp_dmg_bg/dmg_bg_gray.png' width='44' height='16'>}}" 
		}
	}
}