# -*- coding: utf-8 -*-

# Импорт необходимых модулей и классов
from constants import PREMIUM_TYPE  # Константы игры, включая типы премиум-аккаунтов
from gui.Scaleform.daapi.view.lobby.header.LobbyHeader import LobbyHeader  # Класс заголовка лобби
from gui.server_events.events_helpers import dailyQuestsSortFunc  # Функция сортировки ежедневных квестов
from quest_cache_helpers import makeI18nString  # Утилита для создания локализованных строк
from skeletons.gui.server_events import IEventsCache  # Интерфейс кэша событий сервера
from helpers import dependency  # Утилита для работы с зависимостями
from gui.Scaleform.daapi.view.lobby.hangar.Hangar import Hangar  # Класс ангара

# Импорт модулей для работы с событиями и логами
from xfw.events import registerEvent  # Декоратор для регистрации событий
from xvm_main.logger import *  # Модуль логирования из XVM

# Импорт модуля total_Efficiency для доступа к статистике боя
import xvm.total_Efficiency as te

# Словарь для сопоставления ключей описаний с ключами прогресса
progressDataKey = {
    '#quests:dailyQuests/condition/winBattle_accum': 'battlesCount',  # Ключ для квестов на количество боёв
    '#quests:dailyQuests/condition/expTop': 'battlesCount',  # Ключ для квестов на топ по опыту
    '#quests:dailyQuests/condition/dmgTop': 'battlesCount'  # Ключ для квестов на топ по урону
}

# Словарь для хранения текущих значений прогресса
progressDataValues = {
    'damaged': 0,  # Количество подбитых машин
    'kills': 0,  # Количество уничтоженных врагов
    'damageDealt': 0,  # Нанесённый урон
    'critsCount': 0,  # Количество критических попаданий
    'xp': 0,  # Заработанный опыт
    'spotted': 0  # Количество обнаруженных врагов
}

# Глобальная переменная для хранения статуса премиум-аккаунта
isPremiumAccount = False  # По умолчанию премиум-аккаунт отключён

# Определение класса для обработки квестов
class QuestProcessor:
    """Класс для обработки квестов и хранения данных о них."""
    
    def __init__(self):
        # Инициализация словаря для хранения описаний квестов разных типов
        self.questsDescription = {
            'easy': {},        # Лёгкие квесты
            'medium': {},      # Средние квесты
            'hard': {},        # Сложные квесты
            'bonus': {},       # Бонусные квесты
            'premium_easy': {},    # Премиум лёгкие квесты
            'premium_medium': {},  # Премиум средние квесты
            'premium_hard': {}     # Премиум сложные квесты
        }
        # Инициализация зависимости для доступа к кэшу событий
        self.eventsCache = dependency.instance(IEventsCache)  # Получение экземпляра кэша событий

    def processQuestsInHangar(self):
        """Обрабатывает квесты при входе или выходе из ангара."""
        # Получение всех ежедневных квестов и их сортировка
        quests = sorted(self.eventsCache.getDailyQuests().values(), key=dailyQuestsSortFunc)
        # Обработка каждого обычного квеста
        for q in quests:
            level = q.getLevel()  # Получение уровня квеста (easy, medium, hard, bonus)
            quest_info = self.processQuest(q, is_premium=False)  # Обработка квеста
            self.questsDescription[level] = quest_info  # Сохранение данных квеста в словаре
            # Логирование информации о квесте
            log('Regular Quest [{}]: QuestName={}, Type={}, Description="{}", Data={}, Progress={}'.format(
                level, q.getUserName(), quest_info.get('type', 'None'), quest_info.get('description', ''), q.getData(), q.getProgressData()))

        # Получение всех премиум ежедневных квестов и их сортировка
        premiumQuests = sorted(self.eventsCache.getDailyPremiumQuests().values(), key=dailyQuestsSortFunc)
        # Обработка каждого премиум-квеста
        for q in premiumQuests:
            base_level = q.getLevel().split('_')[0]  # Извлечение базового уровня (например, 'easy' из 'easy_premium')
            level = 'premium_' + base_level  # Формирование ключа для премиум-квеста
            quest_info = self.processQuest(q, is_premium=True)  # Обработка премиум-квеста
            self.questsDescription[level] = quest_info  # Сохранение данных премиум-квеста
            # Логирование информации о премиум-квесте
            log('Premium Quest [{}]: QuestName={}, Type={}, Description="{}", Data={}, Progress={}'.format(
                level, q.getUserName(), quest_info.get('type', 'None'), quest_info.get('description', ''), q.getData(), q.getProgressData()))

    def processQuest(self, q, is_premium=False):
        """Обрабатывает данные одного квеста и возвращает словарь с информацией."""
        conditions = q.getData()['conditions']  # Получение условий квеста из данных
        progressData = q.getProgressData()  # Получение данных о прогрессе квеста
        questDescription = self.extractQuestDescription(conditions)  # Извлечение описания квеста
        questValue = self.extractQuestValue(conditions, questDescription)  # Извлечение целевого значения
        progressDataValue = self.extractProgressData(progressData, questDescription)  # Извлечение текущего прогресса
        questType = self.extractQuestType(conditions)  # Извлечение типа квеста
        descKey = questDescription.get('descriptionKey')  # Извлечение i18n-ключа

        if descKey in progressDataKey:
            questKey = progressDataKey[descKey]  # 'battlesCount' для expTop и dmgTop
        else:
            # во всех остальных случаях используем локальный ключ из описания
            questKey = questDescription.get('key', None)

        # Логирование детальной информации о квесте
        log('QuestName={}, Type={}, DescriptionKey={}, QuestKey={}, Description="{}", Data={}, Value={}, Progress={}'.format(
            q.getUserName(),                            # 1
            questType or 'None',                        # 2
            descKey or '',                              # 3
            questKey or '',                             # 4
            questDescription.get('description', ''),    # 5
            q.getData(),                                # 6
            questValue,                                 # 7
            progressDataValue                           # 8
        ))

        # Формирование словаря с данными квеста для возврата
        return {
            'description': questDescription.get('description', None),  # Описание квеста
            'descriptionKey': descKey, # Оригинальный ключ условия квеста 
            'key': questKey,  # Ключ прогресса
            'value': questValue,  # Целевое значение
            'isCompleted': q.isCompleted(),  # Флаг завершения квеста
            'progressData': progressDataValue,  # Текущий прогресс
            'level': q.getLevel(),  # Уровень квеста
            'type': questType  # Тип квеста
        }

    def extractQuestDescription(self, conditions):
        """Извлекает описание квеста из условий, приоритетно из postBattle, если нет — из common."""
        # Сначала пытаемся найти в postBattle
        for condition in conditions:
            if 'postBattle' in condition:
                _, postBattle = condition
                if postBattle:
                    name, result = postBattle[0]
                    return self.readResultSection(result)
        # Если postBattle пуст, ищем в common
        for condition in conditions:
            if 'common' in condition:
                common = condition[1]
                for item in common:
                    if 'cumulative' in item:
                        _, cumulative = item
                        _, result = cumulative[0]
                        return self.readResultSection(result)
        return {}  # Возврат пустого словаря, если не найдено

    def extractQuestValue(self, conditions, questDescription):
        """Извлекает целевое значение квеста, учитывая специальные ключи и секции postBattle/common."""
        specialKeys = ['#quests:dailyQuests/condition/dmgTop', '#quests:dailyQuests/condition/expTop']
        descriptionKey = questDescription.get('descriptionKey')
        
        # Для специальных ключей извлекаем значение из common
        if descriptionKey in specialKeys:
            for condition in conditions:
                if 'common' in condition:
                    common = condition[1]
                    if not common:
                        return 1
                    for name in common:
                        if 'battles' in name:
                            _, battles = name
                            for item in battles:
                                if 'count' in item:
                                    _, count = item
                                    for subitem in count:
                                        if 'value' in subitem:
                                            _, value = subitem
                                            return value
                            return 1
                    return 1
        # Для обычных квестов возвращаем значение из questDescription
        return questDescription.get('value', None)

    def extractProgressData(self, progressData, questDescription):
        """Извлекает текущее значение прогресса квеста."""
        if None in progressData:  # Проверка наличия данных прогресса
            descriptionKey = questDescription.get('descriptionKey')  # Получение ключа описания
            if descriptionKey in progressDataKey:  # Если ключ есть в progressDataKey
                key = progressDataKey[descriptionKey]  # Используем ключ из словаря для специальных квестов
            else:
                key = questDescription.get('key', None)  # Использование ключа из описания
            return progressData[None].get(key, 0)  # Получение значения прогресса или 0
        return 0  # Возврат 0, если данных нет

    def extractQuestType(self, conditions):
        """Извлекает тип квеста из условий."""
        # Перебор всех условий
        for condition in conditions:
            if 'postBattle' in condition:  # Проверка наличия postBattle
                _, postBattle = condition  # Извлечение данных postBattle
                if postBattle:  # Если секция не пуста
                    name, result = postBattle[0]  # Получение имени и результата
                    # Перебор элементов результата
                    for item in result:
                        if 'key' in item:  # Проверка наличия ключа
                            _, key = item  # Извлечение ключа
                            if key:  # Если ключ существует
                                return key[0][1]  # Возврат типа квеста
            elif 'common' in condition:  # Проверка наличия common
                common = condition[1]  # Извлечение данных common
                # Перебор элементов в common
                for name in common:
                    if 'bonusLimit' not in name:  # Исключение bonusLimit
                        if 'cumulative' in name:  # Проверка наличия cumulative
                            _, cumulative = name  # Извлечение cumulative
                            _, result = cumulative[0]  # Получение результата
                        else:
                            _, result = name  # Получение результата напрямую
                        # Перебор элементов результата
                        for item in result:
                            if 'key' in item:  # Проверка наличия ключа
                                _, key = item  # Извлечение ключа
                                if key:  # Если ключ существует
                                    return key[0][1]  # Возврат типа квеста
        return None  # Возврат None, если тип не найден

    def readResultSection(self, result):
        """Читает секцию результата и возвращает описание, ключ и значение."""
        description = key = value = descriptionKey = None
        for values in result:
            if isinstance(values, (list, tuple)):
                if 'description' in values:
                    _, descriptionKey = values
                    if isinstance(descriptionKey, dict) and 'key' in descriptionKey:
                        descriptionKey = descriptionKey['key']
                        description = makeI18nString(descriptionKey)
                elif 'key' in values:
                    _, key = values
                    if key and isinstance(key, (list, tuple)):
                        key = key[0][1]
                elif isinstance(values[1], (list, tuple)) and 'value' in values[1][0]:
                        _, op_data = values
                        _, value = op_data[0]

        # Форматируем описание с учетом значения, если оно есть
        if value is not None and description and '%(value)' in description:
            description = description % {'value': value}
        return {
            'description': description,
            'descriptionKey': descriptionKey,
            'key': key,
            'value': value
        } if descriptionKey else {}

# Создание экземпляра процессора квестов
questProcessor = QuestProcessor()

# Регистрация событий для ангара
@registerEvent(Hangar, '_dispose')
def Hangar_dispose(self):
    """Вызывается при выходе из ангара."""
    questProcessor.processQuestsInHangar()  # Обработка квестов

@registerEvent(Hangar, '_populate')
def Hangar_populate(self):
    """Вызывается при входе в ангар."""
    questProcessor.processQuestsInHangar()  # Обработка квестов

# Функция для обновления данных прогресса
def updateProgressData():
    """Обновляет значения прогресса на основе статистики боя."""
    global progressDataValues  # Использование глобального словаря
    # Обновление значений прогресса из total_Efficiency
    progressDataValues = {
        'damaged': len(te.numberDamagedVehicles) if te.numberDamagedVehicles is not None else 0,  # Подбитые машины
        'kills': te.ribbonTypes['kill'],  # Уничтоженные враги
        'damageDealt': te.totalDamage,  # Нанесённый урон
        'critsCount': te.ribbonTypes['crits'],  # Критические попадания
        'spotted': te.ribbonTypes['spotted']  # Обнаруженные враги
    }

# Функция для получения текущего прогресса квеста
def getProgressData(quest):
    """Возвращает текущий прогресс квеста."""
    # если квест завершён — сразу None
    if quest.get('isCompleted', True):
        return None

    key = quest.get('key', None)                # Получение ключа прогресса
    prog = quest.get('progressData', None)       # Серверный прогресс (может быть 0)

    # если серверный прогресс известен (включая 0), складываем его с «живым» прогрессом
    if prog is not None:
        live = 0
        if key in progressDataValues:
            updateProgressData()                 # Обновление значений из total_Efficiency
            live = progressDataValues[key]       # Локальный (живой) прогресс
        return prog + live                       # Сумма серверного и локального прогресса

    return None


# Функция для получения описания квеста
def getQuestDescription(quest):
    """Возвращает описание квеста, если он не завершён."""
    if quest.get('isCompleted', True):  # Если квест завершён
        return None  # Возврат None
    return quest.get('description', '')  # Возврат описания или пустой строки

# Функция для получения целевого значения квеста
def getQuestValue(quest):
    """Возвращает целевое значение квеста, если он не завершён."""
    if quest.get('isCompleted', True):  # Если квест завершён
        return None  # Возврат None
    return quest.get('value', '')  # Возврат значения или пустой строки

# Функция для вычисления ширины текста описания
def calculate_width(descr):
    """Вычисляет ширину текстового поля описания."""
    if not descr:  # Если описание пустое
        return 0  # Возврат 0
    char_width = 7  # Средняя ширина символа в пикселях
    padding = 60  # Фиксированные отступы
    length = len(descr)  # Длина описания в символах
    width = length * char_width + padding  # Вычисление ширины
    # log(u'Text: "{}", Length: {}, Width: {}'.format(descr, length, width).encode('utf-8'))
    return max(width, 220)  # Возврат ширины, но не менее указанной (width, 220)

# Обработка статуса премиум-аккаунта
@registerEvent(LobbyHeader, '_LobbyHeader__setAccountsAttrs')
def _LobbyHeader__setAccountsAttrs(self):
    """Обновляет статус премиум-аккаунта."""
    global isPremiumAccount  # Использование глобальной переменной
    isPremiumAccount = self.itemsCache.items.stats.isPremium  # Получение статуса из кэша
    # Логирование статуса премиум-аккаунта
    # log('Premium status: isPremiumAccount=%s' % isPremiumAccount)

# Функция для получения CondKey
def getQuestCondKey(questInfo):
    """Возвращает часть descriptionKey после 'condition/'."""
    if not isinstance(questInfo, dict) or questInfo.get('isCompleted', True):  # Проверка типа и завершения
        return None  # Возврат None, если квест завершён или данные некорректны
    desc_key = questInfo.get('descriptionKey')  # Получение ключа описания
    if not desc_key:  # Если ключ отсутствует
        return None  # Возврат None
    parts = desc_key.split('condition/', 1)  # Разделение строки по 'condition/'
    return parts[1] if len(parts) == 2 else None  # Возврат части после 'condition/' или None

# ───────────────────────────────────────────────────────
# Флаг проверки разблокировки бонусной миссии
ENABLE_BONUS_LOCK_CHECK = True  # Поставьте False — бонус будет доступен всегда

def isBonusAvailable():
    """Проверяет, выполнены ли три стандартные миссии easy/medium/hard."""
    completed = 0
    for lvl in ('easy', 'medium', 'hard'):
        q = questProcessor.questsDescription.get(lvl, {})
        if q.get('isCompleted', False):
            completed += 1
    return completed >= 3

# ───────────────────────────────────────────────────────
# 1) Описание (description)
# ───────────────────────────────────────────────────────
# Обычные квесты
@xvm.export('dq.easyDescr', deterministic=False)
def dq_easyDescr():
    """Макрос для получения описания лёгкого квеста."""
    return getQuestDescription(questProcessor.questsDescription.get('easy', {}))  # Возврат описания

@xvm.export('dq.mediumDescr', deterministic=False)
def dq_mediumDescr():
    """Макрос для получения описания среднего квеста."""
    return getQuestDescription(questProcessor.questsDescription.get('medium', {}))  # Возврат описания

@xvm.export('dq.hardDescr', deterministic=False)
def dq_hardDescr():
    """Макрос для получения описания сложного квеста."""
    return getQuestDescription(questProcessor.questsDescription.get('hard', {}))  # Возврат описания

@xvm.export('dq.bonusDescr', deterministic=False)
def dq_bonusDescr():
    """Макрос для получения описания бонусного квеста."""
    if ENABLE_BONUS_LOCK_CHECK and not isBonusAvailable():
        return None
    return getQuestDescription(questProcessor.questsDescription.get('bonus', {}))  # Возврат описания

# Премиум-квесты
@xvm.export('dq.premiumEasyDescr', deterministic=False)
def dq_premiumEasyDescr():
    """Макрос для получения описания премиум лёгкого квеста."""
    if not isPremiumAccount:
        return None
    return getQuestDescription(questProcessor.questsDescription.get('premium_easy', {}))  # Возврат описания

@xvm.export('dq.premiumMediumDescr', deterministic=False)
def dq_premiumMediumDescr():
    """Макрос для получения описания премиум среднего квеста."""
    if not isPremiumAccount:
        return None
    return getQuestDescription(questProcessor.questsDescription.get('premium_medium', {}))  # Возврат описания

@xvm.export('dq.premiumHardDescr', deterministic=False)
def dq_premiumHardDescr():
    """Макрос для получения описания премиум сложного квеста."""
    if not isPremiumAccount:
        return None
    return getQuestDescription(questProcessor.questsDescription.get('premium_hard', {}))  # Возврат описания


# ───────────────────────────────────────────────────────
# 2) Прогресс (progressData)
# ───────────────────────────────────────────────────────
# Обычные квесты
@xvm.export('dq.easyProgress', deterministic=False)
def dq_easyProgress():
    """Макрос для получения прогресса лёгкого квеста."""
    return getProgressData(questProcessor.questsDescription.get('easy', {}))  # Возврат прогресса

@xvm.export('dq.mediumProgress', deterministic=False)
def dq_mediumProgress():
    """Макрос для получения прогресса среднего квеста."""
    return getProgressData(questProcessor.questsDescription.get('medium', {}))  # Возврат прогресса

@xvm.export('dq.hardProgress', deterministic=False)
def dq_hardProgress():
    """Макрос для получения прогресса сложного квеста."""
    return getProgressData(questProcessor.questsDescription.get('hard', {}))  # Возврат прогресса

@xvm.export('dq.bonusProgress', deterministic=False)
def dq_bonusProgress():
    """Макрос для получения прогресса бонусного квеста."""
    if ENABLE_BONUS_LOCK_CHECK and not isBonusAvailable():
        return None
    return getProgressData(questProcessor.questsDescription.get('bonus', {}))  # Возврат прогресса

# Премиум-квесты
@xvm.export('dq.premiumEasyProgress', deterministic=False)
def dq_premiumEasyProgress():
    """Макрос для получения прогресса премиум лёгкого квеста."""
    if not isPremiumAccount:
        return None
    return getProgressData(questProcessor.questsDescription.get('premium_easy', {}))  # Возврат прогресса

@xvm.export('dq.premiumMediumProgress', deterministic=False)
def dq_premiumMediumProgress():
    """Макрос для получения прогресса премиум среднего квеста."""
    if not isPremiumAccount:
        return None
    return getProgressData(questProcessor.questsDescription.get('premium_medium', {}))  # Возврат прогресса

@xvm.export('dq.premiumHardProgress', deterministic=False)
def dq_premiumHardProgress():
    """Макрос для получения прогресса премиум сложного квеста."""
    if not isPremiumAccount:
        return None
    return getProgressData(questProcessor.questsDescription.get('premium_hard', {}))  # Возврат прогресса


# ───────────────────────────────────────────────────────
# 3) Целевое значение (value)
# ───────────────────────────────────────────────────────
# Обычные квесты
@xvm.export('dq.easyValue', deterministic=False)
def dq_easyValue():
    """Макрос для получения целевого значения лёгкого квеста."""
    return getQuestValue(questProcessor.questsDescription.get('easy', {}))  # Возврат значения

@xvm.export('dq.mediumValue', deterministic=False)
def dq_mediumValue():
    """Макрос для получения целевого значения среднего квеста."""
    return getQuestValue(questProcessor.questsDescription.get('medium', {}))  # Возврат значения

@xvm.export('dq.hardValue', deterministic=False)
def dq_hardValue():
    """Макрос для получения целевого значения сложного квеста."""
    return getQuestValue(questProcessor.questsDescription.get('hard', {}))  # Возврат значения

@xvm.export('dq.bonusValue', deterministic=False)
def dq_bonusValue():
    """Макрос для получения целевого значения бонусного квеста."""
    if ENABLE_BONUS_LOCK_CHECK and not isBonusAvailable():
        return None
    return getQuestValue(questProcessor.questsDescription.get('bonus', {}))  # Возврат значения

# Премиум-квесты
@xvm.export('dq.premiumEasyValue', deterministic=False)
def dq_premiumEasyValue():
    """Макрос для получения целевого значения премиум лёгкого квеста."""
    if not isPremiumAccount:
        return None
    return getQuestValue(questProcessor.questsDescription.get('premium_easy', {}))  # Возврат значения

@xvm.export('dq.premiumMediumValue', deterministic=False)
def dq_premiumMediumValue():
    """Макрос для получения целевого значения премиум среднего квеста."""
    if not isPremiumAccount:
        return None
    return getQuestValue(questProcessor.questsDescription.get('premium_medium', {}))  # Возврат значения

@xvm.export('dq.premiumHardValue', deterministic=False)
def dq_premiumHardValue():
    """Макрос для получения целевого значения премиум сложного квеста."""
    if not isPremiumAccount:
        return None
    return getQuestValue(questProcessor.questsDescription.get('premium_hard', {}))  # Возврат значения


# ───────────────────────────────────────────────────────
# 4) Ширина описания (descrWidth)
# ───────────────────────────────────────────────────────
# Обычные квесты
@xvm.export('dq.easyDescrWidth', deterministic=False)
def dq_easyDescrWidth():
    """Макрос для получения ширины описания лёгкого квеста."""
    return calculate_width(dq_easyDescr())  # Вычисление и возврат ширины

@xvm.export('dq.mediumDescrWidth', deterministic=False)
def dq_mediumDescrWidth():
    """Макрос для получения ширины описания среднего квеста."""
    return calculate_width(dq_mediumDescr())  # Вычисление и возврат ширины

@xvm.export('dq.hardDescrWidth', deterministic=False)
def dq_hardDescrWidth():
    """Макрос для получения ширины описания сложного квеста."""
    return calculate_width(dq_hardDescr())  # Вычисление и возврат ширины

@xvm.export('dq.bonusDescrWidth', deterministic=False)
def dq_bonusDescrWidth():
    """Макрос для получения ширины описания бонусного квеста."""
    return calculate_width(dq_bonusDescr())  # Вычисление и возврат ширины

# Премиум-квесты
@xvm.export('dq.premiumEasyDescrWidth', deterministic=False)
def dq_premiumEasyDescrWidth():
    """Макрос для получения ширины описания премиум лёгкого квеста."""
    if not isPremiumAccount:
        return 0
    return calculate_width(dq_premiumEasyDescr())  # Вычисление и возврат ширины

@xvm.export('dq.premiumMediumDescrWidth', deterministic=False)
def dq_premiumMediumDescrWidth():
    """Макрос для получения ширины описания премиум среднего квеста."""
    if not isPremiumAccount:
        return 0
    return calculate_width(dq_premiumMediumDescr())  # Вычисление и возврат ширины

@xvm.export('dq.premiumHardDescrWidth', deterministic=False)
def dq_premiumHardDescrWidth():
    """Макрос для получения ширины описания премиум сложного квеста."""
    if not isPremiumAccount:
        return 0
    return calculate_width(dq_premiumHardDescr())  # Вычисление и возврат ширины

# ───────────────────────────────────────────────────────
# 5) Тип миссии (type)
# ───────────────────────────────────────────────────────

# Обычные квесты
@xvm.export('dq.easyType', deterministic=False)
def dq_easyType():
    """Макрос для получения типа лёгкого квеста."""
    return questProcessor.questsDescription.get('easy', {}).get('type', None)  # Возврат типа

@xvm.export('dq.mediumType', deterministic=False)
def dq_mediumType():
    """Макрос для получения типа среднего квеста."""
    return questProcessor.questsDescription.get('medium', {}).get('type', None)  # Возврат типа

@xvm.export('dq.hardType', deterministic=False)
def dq_hardType():
    """Макрос для получения типа сложного квеста."""
    return questProcessor.questsDescription.get('hard', {}).get('type', None)  # Возврат типа

@xvm.export('dq.bonusType', deterministic=False)
def dq_bonusType():
    """Макрос для получения типа бонусного квеста."""
    return questProcessor.questsDescription.get('bonus', {}).get('type', None)  # Возврат типа

# Премиум-квесты
@xvm.export('dq.premiumEasyType', deterministic=False)
def dq_premiumEasyType():
    """Макрос для получения типа премиум лёгкого квеста."""
    if not isPremiumAccount:
        return None
    return questProcessor.questsDescription.get('premium_easy', {}).get('type', None)  # Возврат типа

@xvm.export('dq.premiumMediumType', deterministic=False)
def dq_premiumMediumType():
    """Макрос для получения типа премиум среднего квеста."""
    if not isPremiumAccount:
        return None
    return questProcessor.questsDescription.get('premium_medium', {}).get('type', None)  # Возврат типа

@xvm.export('dq.premiumHardType', deterministic=False)
def dq_premiumHardType():
    """Макрос для получения типа премиум сложного квеста."""
    if not isPremiumAccount:
        return None
    return questProcessor.questsDescription.get('premium_hard', {}).get('type', None)  # Возврат типа

# ───────────────────────────────────────────────────────
# 6) Условие (CondKey) — часть descriptionKey после "condition/"
# ───────────────────────────────────────────────────────

# Обычные квесты
@xvm.export('dq.easyCondKey', deterministic=False)
def dq_easyCondKey():
    """Макрос для получения CondKey лёгкого квеста."""
    return getQuestCondKey(questProcessor.questsDescription.get('easy', {}))  # Возврат CondKey

@xvm.export('dq.mediumCondKey', deterministic=False)
def dq_mediumCondKey():
    """Макрос для получения CondKey среднего квеста."""
    return getQuestCondKey(questProcessor.questsDescription.get('medium', {}))  # Возврат CondKey

@xvm.export('dq.hardCondKey', deterministic=False)
def dq_hardCondKey():
    """Макрос для получения CondKey сложного квеста."""
    return getQuestCondKey(questProcessor.questsDescription.get('hard', {}))  # Возврат CondKey

@xvm.export('dq.bonusCondKey', deterministic=False)
def dq_bonusCondKey():
    """Макрос для получения CondKey бонусного квеста."""
    return getQuestCondKey(questProcessor.questsDescription.get('bonus', {}))  # Возврат CondKey

# Премиум-квесты
@xvm.export('dq.premiumEasyCondKey', deterministic=False)
def dq_premiumEasyCondKey():
    """Макрос для получения CondKey премиум лёгкого квеста."""
    if not isPremiumAccount:
        return None
    return getQuestCondKey(questProcessor.questsDescription.get('premium_easy', {}))  # Возврат CondKey

@xvm.export('dq.premiumMediumCondKey', deterministic=False)
def dq_premiumMediumCondKey():
    """Макрос для получения CondKey премиум среднего квеста."""
    if not isPremiumAccount:
        return None
    return getQuestCondKey(questProcessor.questsDescription.get('premium_medium', {}))  # Возврат CondKey

@xvm.export('dq.premiumHardCondKey', deterministic=False)
def dq_premiumHardCondKey():
    """Макрос для получения CondKey премиум сложного квеста."""
    if not isPremiumAccount:
        return None
    return getQuestCondKey(questProcessor.questsDescription.get('premium_hard', {}))  # Возврат CondKey
