import Keys
import game

from gui.battle_control import avatar_getter
from helpers import dependency
from messenger import MessengerEntry
from skeletons.gui.battle_session import IBattleSessionProvider

import xvm_main.config as config
from xfw.events import registerEvent
from xvm_main.logger import *


MODIFIERS = {'none': Keys.KEY_NONE,
             'shift': Keys.MODIFIER_SHIFT,
             'ctrl': Keys.MODIFIER_CTRL,
             'alt': Keys.MODIFIER_ALT}


@registerEvent(game, 'handleKeyEvent', True)
def game_handleKeyEvent(event):
    sessionProvider = dependency.instance(IBattleSessionProvider)
    hotkey = config.get('hotkeys/quicklyLeave', {'enabled': True, 'keyCode': Keys.KEY_F4, 'modifier': 'none'})
    if hotkey.get('enabled', True) and sessionProvider.getArenaDP() is not None:
        if MessengerEntry.g_instance.gui.isFocused():
            return
        isDown, key, mods, isRepeat = game.convertKeyEvent(event)
        if key == hotkey.get('keyCode', Keys.KEY_F4) and isDown and not isRepeat:
            modifier = str(hotkey.get('modifier', 'none')).lower()
            if mods != MODIFIERS.get(modifier, 'none'):
                return
            arenaDP = sessionProvider.getArenaDP()
            vStats = arenaDP.getVehicleStats()
            arenaVisitor = sessionProvider.arenaVisitor
            if not sessionProvider.isReplayPlaying and not arenaVisitor.gui.isTrainingBattle() and not arenaVisitor.gui.isBattleRoyale() and not arenaVisitor.gui.isMapsTraining():
                if arenaVisitor.hasRespawns():
                    isDeserter = not vStats.stopRespawn
                else:
                    isDeserter = avatar_getter.isVehicleAlive()
            else:
                isDeserter = False
            if isDeserter:
                return
            sessionProvider.exit()
