from constants import SHELL_TYPES
from gui.shared.personality import ServicesLocator
from helpers import dependency
from skeletons.gui.app_loader import GuiGlobalSpaceID
from skeletons.gui.battle_session import IBattleSessionProvider
from Vehicle import Vehicle

from xfw import registerEvent

import xvm_battle.battle as battle

class BattleEvents:

    def __init__(self):
        self.subscribers = set([])
        self._in_battle = False
        ServicesLocator.appLoader.onGUISpaceEntered += self._onGUISpaceEntered
        ServicesLocator.appLoader.onGUISpaceLeft += self._onGUISpaceLeft

    def subscribe(self, subscriber):
        self.subscribers.add(subscriber)

    def _onGUISpaceEntered(self, spaceID):
        if spaceID != GuiGlobalSpaceID.BATTLE:
            return
        if self._in_battle:
            return
        self._in_battle = True

        for subscriber in self.subscribers:
            handler = getattr(subscriber, 'onBattleLoaded', None)
            if handler is not None and callable(handler):
                handler()

    def _onGUISpaceLeft(self, spaceID):
        from skeletons.gui.app_loader import GuiGlobalSpaceID
        if spaceID != GuiGlobalSpaceID.BATTLE:
            return
        if not self._in_battle:
            return
        self._in_battle = False
        for subscriber in self.subscribers:
            handler = getattr(subscriber, 'onBattleClosed', None)
            if handler is not None and callable(handler):
                handler()

class ShellDamageGetter:

    sessionProvider = dependency.descriptor(IBattleSessionProvider)

    def __init__(self):
        self.cleen()

    def onBattleClosed(self):
        self.cleen()

    def onBattleLoaded(self):
        self.cleen()

    def cleen(self):
        self._is_shot_he = False
        self._shot_damage = 0

    def update(self):
        try:
            ammoCtrl = self.sessionProvider.shared.ammo
            if not ammoCtrl:
                return
            shell = ammoCtrl.getGunSettings().getShellDescriptor(ammoCtrl.getCurrentShellCD())
            self._is_shot_he = shell.type.name in SHELL_TYPES.HIGH_EXPLOSIVE
            if hasattr(shell, 'armorDamage'):
                self._shot_damage = int(shell.armorDamage[0])
            elif hasattr(shell, 'damage'):
                self._shot_damage = int(shell.damage[0])
            else:
                return False
            return True
        except:
            return False

    def formatted(self):
        if self._is_shot_he:
            if self._shot_damage:
                return str(int(self._shot_damage // 1.05))
        return str(self._shot_damage)

class PlayerDamageGetter:

    sessionProvider = dependency.descriptor(IBattleSessionProvider)

    def __init__(self):
        self.cleen()

    def onBattleClosed(self):
        self.cleen()

    def onBattleLoaded(self):
        self.cleen()
        self.build_linkages()

    def build_linkages(self):
        arenaDP = self.sessionProvider.getArenaDP()
        for vInfoVO in arenaDP.getVehiclesInfoIterator():
            self.linkages[vInfoVO.player.name] = vInfoVO.vehicleID

    def register_damage(self, vehicle_id, damage_dealt):
        if vehicle_id not in self.damage_dealt:
            self.damage_dealt[vehicle_id] = 0
        self.damage_dealt[vehicle_id] += damage_dealt

    def cleen(self):
        self.damage_dealt = {}
        self.linkages = {}

    def get_damage(self, nickname):
        if nickname not in self.linkages:
            self.build_linkages()
            if nickname not in self.linkages:
                return
        vehicle_id = self.linkages[nickname]
        if vehicle_id not in self.damage_dealt:
            return
        return self.damage_dealt[vehicle_id]


battle_events = BattleEvents()

shell_damage_getter = ShellDamageGetter()
battle_events.subscribe(shell_damage_getter)

player_damage_getter = PlayerDamageGetter()
battle_events.subscribe(player_damage_getter)


@registerEvent(Vehicle, 'onHealthChanged')
def onHealthChanged(self, newHealth, oldHealth, attackerID, *a, **kw):
    if not battle.isBattleTypeSupported:
        return
    damage_dealt = oldHealth - max(0, newHealth)
    player_damage_getter.register_damage(attackerID, damage_dealt)

class DataProvider:

    def get_player_damage(self, player_name):
        formatted = player_damage_getter.get_damage(player_name)
        if formatted:
            return formatted
        return '0'

    def get_shell_damage(self):
        updated = shell_damage_getter.update()
        if updated:
            formatted = shell_damage_getter.formatted()
            if formatted:
                return formatted
        return '400'

data_provider = DataProvider()

@xvm.export('shell_damage.shell_damage', deterministic=False)
def shell_damage():
    return data_provider.get_shell_damage()

@xvm.export('player_damage.player_damage', deterministic=False)
def shell_damage(player_name=""):
    return data_provider.get_player_damage(player_name)
