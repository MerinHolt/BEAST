﻿import traceback
from xvm.hitLog import g_dataHitLog
from helpers import getClientLanguage

@xvm.export('xvm.hitLog.alive', deterministic=False)
def xvm_hitLog_alive():
    return g_dataHitLog.macros['alive'] if 'alive' in g_dataHitLog.macros else ''

@xvm.export('xvm.hitLog.blowup', deterministic=False)
def xvm_hitLog_blowup():
    return g_dataHitLog.macros['blownup'] if 'blownup' in g_dataHitLog.macros else ''

@xvm.export('xvm.hitLog.dmgString', deterministic=True)
def xvm_hitLog_dmgString():
    lng = getClientLanguage()
    if lng == 'ru':
        return 'Урон'
    elif lng == 'uk':
        return 'Шкода'
    elif lng == 'be':
        return 'Пашкоджанні'
    elif lng == 'kk':
        return 'Зақым'
    return 'Damage'
