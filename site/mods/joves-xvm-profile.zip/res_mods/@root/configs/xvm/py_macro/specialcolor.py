from xvm_main.vehinfo_tiers import _special, _getTiers
import xvm_main.config as config
from items import vehicles
from copy import copy

@xvm.export('specialColor.battleTiers')
def battleTiers(*args):

    name, color1, color2 = args
    name = name.replace('-', ':', 1)

    if name not in _special:
        return color2

    vDesc = vehicles.VehicleDescr(typeName = name)
    preferential = preferential in vDesc.type.tags
    cls = __getTankClass(vDesc.type.tags)

    tMin, tMax = _getTiers(vDesc.level, cls, '')
    tMin2, tMax2 = _special[name]

    return color1 if tMax2 < tMax else color2

def __getTankClass(tags):
    if 'lightTank' in tags: return 'lightTank'
    if 'heavyTank' in tags: return 'heavyTank'
    return ''



def getColorsDamageRating():
    ratings = copy(config.get('colors/damageRating'))
    ratings.sort(key = lambda x: x['value'])
    res = {0:0, 1:0, 2:0, 3:0}

    for v in ratings:
        if v['value'] < 65:
            res[0] = v['color']
        elif v['value'] < 85:
            res[1] = v['color']
        elif v['value'] < 95:
            res[2] = v['color']
        else:
            res[3] = v['color']

    def processColor(clr):
        return '#' + clr[2:] if clr[:2] == '0x' else clr

    return [
        processColor(res[0]),
        processColor(res[1]),
        processColor(res[2]),
        processColor(res[3])
    ]

colors_damageRating = getColorsDamageRating()

@xvm.export('specialColor.marksOnGun')
def marksOnGun(ratingId=0):
    return colors_damageRating[ratingId]