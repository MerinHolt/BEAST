﻿{
    // true - show counter on buttons for new items.
    // true - показывать счётчик на кнопках для новых вещей.	
    "showButtonCounters": true
}