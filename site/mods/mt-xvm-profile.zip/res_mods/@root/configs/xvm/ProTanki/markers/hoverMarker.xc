﻿{
    // Hover marker
    // Маркер по наведениюы
    "hoverMarker": {
      "enabled": true,   	// false - disable        / не отображать.
      "x": 0,            	// Position on the X axis / Положение по оси X.
      "y": ${"playerName.xc":"y_hoverMarker"},
      "alpha": 100,      	// Opacity                / Прозрачность.
      "glow": {
        "enabled": false,   // false - disable        / не отображать.
        "x": 0,            	// Position on the X axis / Положение по оси X.
        "y": 0,           	// Position on the Y axis / Положение по оси Y.
        "alpha": 50        	// Opacity                / Прозрачность.
		}
	}
}