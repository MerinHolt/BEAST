﻿{
    // true - Иконка фокуса противника включена
    "enabledkillEnemy": false
}