﻿{
    // false - use standard client vehicle markers.
    // false - использовать стандартные маркеры клиента.
    "enabledMarkers": true
}