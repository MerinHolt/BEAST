﻿{
    // Text field with the name of the player.
    // Текстовое поле с именем игрока.
    "enabledplayerName": true,
	"y_vehicleDist": -86,
	"y_damageText": -79,
	"y_hoverMarker": -84
}