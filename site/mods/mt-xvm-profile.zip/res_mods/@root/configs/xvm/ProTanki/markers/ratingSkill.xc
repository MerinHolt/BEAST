﻿{
    // Text field with rating.
    // Текстовое поле с рейтингом.
    "ratingSkill": {
      "name": "ratingSkill",
      "enabled": true,
      "x": 0,
      "y": -6,
      "alpha": "55",
      "color": "0xFFFF00",
	  "align": "center",
      "textFormat": {
        "font": "$FieldFont",
        "size": 13,
        "bold": false,
        "italic": false
      },
      "shadow": {
	    // false - no shadow
        // false - без тени
        "enabled": true,
        "distance": 0,
        "angle": 90,
        "color": null,
        "alpha": 30,
        "blur": 6,
        "strength": 2
      },
       "format": "{{xvm-stat?<img src='xvm://res/icons/skill/{{c:xr|#999999}}.png' width='68' height='3'>}}"
    }
}