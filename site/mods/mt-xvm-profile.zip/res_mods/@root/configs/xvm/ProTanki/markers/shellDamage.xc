﻿/**
 * Настройка числа выстрелов в маркерах для противников.
 */
{
	"format": "{{hp}} / {{py:sum({{py:div({{hp>0?{{hp}}|0}},{{py:protanki.shell_damage|None}})}},0.5)%d}} \ {{hp-max}}"
}
