﻿{
    // true - Vehicle distance on
    // true - Дистанция до техники включена
    "enabledvehicleDist": true
}