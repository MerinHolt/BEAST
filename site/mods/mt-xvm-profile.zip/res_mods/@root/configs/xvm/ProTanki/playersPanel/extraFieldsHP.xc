﻿{
    "hpBarLeft": {
		// HP bar background Left.
		// Подложка индикатора HP слева.
		"hpBarBg": { 
			"hotKeyCode": 56,
			"onHold": "true",
			"visibleOnHotKey": ${"teams_hp.xc":"visibleOnHotKey"},
			"x": 90,
			"y": 6,
			"width": 52,
			"bindToIcon": true,
			"height": 14,
			"bgColor": "0x000000",
			"alpha": "{{py:xvm.screenWidth<1441?0|{{alive?35|0}}}}" 
		},
		// HP bar Left.
		// Индикатор HP слева.
		"hpBar": {
			"hotKeyCode": 56,
			"onHold": "true",
			"visibleOnHotKey": ${"teams_hp.xc":"visibleOnHotKey"},
			"x": 91,
			"y": 7,
			"bindToIcon": true,
			"width": "{{hp-ratio:50}}",
			"height": 12,
			"bgColor": "{{player?#FFDD33|{{c:system}}}}",
			"alpha": "{{py:xvm.screenWidth<1441?0|{{alive?50|0}}}}" 
		},
		// Remaining HP Left.
		// Оставшиеся HP слева.
		"hp": {
		  "hotKeyCode": 56,
		  "onHold": "true",
		  "visibleOnHotKey": ${"teams_hp.xc":"visibleOnHotKey"},
		  "bindToIcon": true,
		  "alpha": "{{py:xvm.screenWidth<1441?0|{{alive?100|0}}}}",
		  "x": 90,
		  "width": 52,
		  "y": 4,
		  "textFormat": { "font": "$FieldFont", "size": 11, "color": "0xD9D9D9", "bold": "true", "align": "center" },
		  "format": "<font alpha='{{alive?{{ready?#FF|#80}}|#80}}'>{{alive?{{hp|{{hp-max}}}}|{{l10n:Destroyed}}}}</font>",
		  "shadow": { "enabled": true, "color": "0x000000", "alpha": 100, "blur": 4, "strength": 1, "distance": 0, "angle": 0 }
		}
	},  
    "hpBarRight": {
		// HP bar background Right.
		// Подложка индикатора HP Справа.
		"hpBarBg": {
			"hotKeyCode": 56,
			"onHold": "true",
			"visibleOnHotKey": ${"teams_hp.xc":"visibleOnHotKey"},
			"x": 90,
			"y": 6,
			"width": 52,
			"bindToIcon": true,
			"height": 14,
			"bgColor": "0x000000",
			"alpha": "{{alive?35|0}}"
		},
		// HP bar Right.
		// Индикатор HP Справа.
		"hpBar": {
			"hotKeyCode": 56,
			"onHold": "true",
			"visibleOnHotKey": ${"teams_hp.xc":"visibleOnHotKey"},
			"x": 91,
			"y": 7,
			"bindToIcon": true,
			"width": "{{hp-ratio:50}}",
			"height": 12,
			"bgColor": "{{player?#FFDD33|{{c:system}}}}",
			"alpha": "{{alive?50|0}}" 
		},
		// Remaining HP Right.
		// Оставшиеся HP Справа.
		"hp": {
		  "hotKeyCode": 56,
		  "onHold": "true",
		  "visibleOnHotKey": ${"teams_hp.xc":"visibleOnHotKey"},
		  "bindToIcon": true,
		  "alpha": "{{alive?100|0}}",
		  "x": 91,
		  "width": 52,
		  "y": 4,
		  "textFormat": { "font": "$FieldFont", "size": 11, "color": "0xD9D9D9", "bold": "true", "align": "center" },
		  "format": "<font alpha='{{alive?{{ready?#FF|#80}}|#80}}'>{{alive?{{hp|{{hp-max}}}}|{{l10n:Destroyed}}}}</font>",
		  "shadow": { "enabled": true, "color": "0x000000", "alpha": 100, "blur": 4, "strength": 1, "distance": 0, "angle": 0 }
		}
	} 
}