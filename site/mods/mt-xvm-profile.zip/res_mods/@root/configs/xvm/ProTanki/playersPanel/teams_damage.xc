﻿{
    // true - отображение урона команд по Alt.
    "visibleOnHotKey": false
}