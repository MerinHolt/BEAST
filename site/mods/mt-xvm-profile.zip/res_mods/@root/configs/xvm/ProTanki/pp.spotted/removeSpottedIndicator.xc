﻿{
      // false - enable enemy spotted status icons.
      // false - допустить отображение иконки статуса засвета противника в клиенте.
      "removeSpottedIndicator": true
}